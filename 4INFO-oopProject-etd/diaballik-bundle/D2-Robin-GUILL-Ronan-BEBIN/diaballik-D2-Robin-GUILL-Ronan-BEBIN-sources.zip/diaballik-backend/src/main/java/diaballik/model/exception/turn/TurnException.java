package diaballik.model.exception.turn;

public class TurnException extends Exception {
}
