package diaballik.model.control;

public interface Action {

    boolean exe();

    boolean canDo();

}
