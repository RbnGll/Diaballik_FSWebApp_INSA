package diaballik.model.exception;

public class CommandException extends Exception {
}
