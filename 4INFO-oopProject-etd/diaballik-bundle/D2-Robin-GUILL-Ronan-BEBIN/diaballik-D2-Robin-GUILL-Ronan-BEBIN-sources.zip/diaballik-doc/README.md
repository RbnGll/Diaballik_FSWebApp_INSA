
Put in this folder:
- the user documentation of the app
- your modelling report
- the slides of your final talk