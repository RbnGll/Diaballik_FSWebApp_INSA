package diaballik.model.exception.turn;

public class UnstartedGameException extends TurnException {
}
