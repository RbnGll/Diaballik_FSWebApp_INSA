package diaballik.model.control;

public interface Undoable {

    public abstract void redo();

    public abstract void undo();

}
