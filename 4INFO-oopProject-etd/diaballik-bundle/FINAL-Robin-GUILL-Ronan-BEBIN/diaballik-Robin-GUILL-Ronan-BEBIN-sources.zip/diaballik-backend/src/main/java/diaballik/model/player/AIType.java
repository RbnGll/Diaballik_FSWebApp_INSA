package diaballik.model.player;

public enum AIType {

    NOOB,

    STARTING,

    PROGRESSIVE;

}
