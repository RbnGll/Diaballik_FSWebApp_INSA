package diaballik.model.exception.turn;

public class TurnException extends Exception {

    public TurnException() {
        super();
    }

    public TurnException(final String message) {
        super(message);
    }
}
