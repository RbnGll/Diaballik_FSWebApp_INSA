package diaballik.model.exception.turn;

public class UndoRedoException extends TurnException {
}
