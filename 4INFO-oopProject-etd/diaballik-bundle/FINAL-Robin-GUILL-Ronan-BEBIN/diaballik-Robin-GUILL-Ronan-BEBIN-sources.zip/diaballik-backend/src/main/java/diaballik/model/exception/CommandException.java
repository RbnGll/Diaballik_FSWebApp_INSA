package diaballik.model.exception;

public class CommandException extends Exception {

    public CommandException() {
        super();
    }

    public CommandException(final String message) {
        super(message);
    }

}
