package diaballik.model.exception.turn;

public class EndTurnException extends TurnException {
}
